<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of Exposicion
 *
 * @author OCTAVIO MARTINEZ

class Exposicion {
    private $nombreExposicion;
    private $añoExposicion;
    private $tipoExposicion;

    public function __construct($nombreExposicion, $añoExposicion, $tipoExposicion) {
        $this->nombreExposicion = $nombreExposicion;
        $this->añoExposicion = $añoExposicion;
        $this->tipoExposicion = $tipoExposicion;
    }

    // Getters y Setters
    public function getNombreExposicion() {
        return $this->nombreExposicion;
    }

    public function setNombreExposicion($nombreExposicion) {
        $this->nombreExposicion = $nombreExposicion;
    }

    public function getAñoExposicion() {
        return $this->añoExposicion;
    }

    public function setAñoExposicion($añoExposicion) {
        $this->añoExposicion = $añoExposicion;
    }

    public function getTipoExposicion() {
        return $this->tipoExposicion;
    }

    public function setTipoExposicion($tipoExposicion) {
        $this->tipoExposicion = $tipoExposicion;
    }

    public function __toString() {
        return "Exposicion{" .
            "nombreExposicion='" . $this->nombreExposicion . '\'' .
            

