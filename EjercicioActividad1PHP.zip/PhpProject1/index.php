<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        

// Clase Museo
class Museo {
    private $nombre;
    private $añoFundacion;

    public function __construct($nombre, $añoFundacion) {
        $this->nombre = $nombre;
        $this->añoFundacion = $añoFundacion;
    }

    public function __toString() {
        return "Museo: " . $this->nombre . ", Fundado en: " . $this->añoFundacion;
    }
}

// Clase Artista
class Artista {
    private $id;
    private $nombre;
    private $nacionalidad;
    private $obraFamosa;

    public function __construct($id, $nombre, $nacionalidad, $obraFamosa) {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->nacionalidad = $nacionalidad;
        $this->obraFamosa = $obraFamosa;
    }

    public function __toString() {
        return "Artista: " . $this->nombre . " (" . $this->nacionalidad . "), Obra Famosa: " . $this->obraFamosa;
    }
}

// Clase Coleccion
class Coleccion {
    private $nombreColeccion;

    public function __construct($nombreColeccion) {
        $this->nombreColeccion = $nombreColeccion;
    }

    public function __toString() {
        return "Colección: " . $this->nombreColeccion;
    }
}

// Clase Evento
class Evento {
    private $nombre;
    private $fecha; // Usar DateTime para la fecha
    private $descripcion;

    public function __construct($nombre, $fecha, $descripcion) {
        $this->nombre = $nombre;
        $this->fecha = $fecha; // Debe ser un objeto DateTime
        $this->descripcion = $descripcion;
    }

    public function __toString() {
        return "Evento: " . $this->nombre . ", Fecha: " . $this->fecha->format('Y-m-d') . ", Descripción: " . $this->descripcion;
    }
}

// Clase Exposicion
class Exposicion {
    private $artista;
    private $año;
    private $tema;

    public function __construct($artista, $año, $tema) {
        $this->artista = $artista;
        $this->año = $año;
        $this->tema = $tema;
    }

    public function __toString() {
        return "Exposición: " . $this->tema . " por " . $this->artista . ", Año: " . $this->año;
    }
}
// Clase Guia
class Guia {
    private $nombre;
    private $apellido;
    private $nacionalidad;
    private $idEmpleado;

    public function __construct($nombre, $apellido, $nacionalidad, $idEmpleado) {
        $this->nombre = $nombre;
        $this->apellido = $apellido;
        $this->nacionalidad = $nacionalidad;
        $this->idEmpleado = $idEmpleado;
    }

    public function __toString() {
        return "Guía: " . $this->nombre . " " . $this->apellido . " (" . $this->nacionalidad . "), ID Empleado: " . $this->idEmpleado;
    }
}

// Clase Obra
class Obra {
    private $nombreObra;
    private $nombreArtista;
    private $añoCreacion;

    public function __construct($nombreObra, $nombreArtista, $añoCreacion) {
        $this->nombreObra = $nombreObra;
        $this->nombreArtista = $nombreArtista;
        $this->añoCreacion = $añoCreacion;
    }

    public function __toString() {
        return "Obra: " . $this->nombreObra . " por " . $this->nombreArtista . ", Año: " . $this->añoCreacion;
    }
}

// Clase Ticket
class Ticket {
    private $tipoEntrada;
    private $precio;
    private $codigo;

    public function __construct($tipoEntrada, $precio, $codigo) {
        $this->tipoEntrada = $tipoEntrada;
        $this->precio = $precio;
        $this->codigo = $codigo;
    }

    public function __toString() {
        return "Ticket: " . $this->tipoEntrada . ", Precio: " . $this->precio . ", Código: " . $this->codigo;
    }
}

// Clase Visitante
class Visitante {
    private $nombre;
    private $apellido;
    private $nacionalidad;
    private $idVisitante;

    public function __construct($nombre, $apellido, $nacionalidad, $idVisitante) {
        $this->nombre = $nombre;
        $this->apellido = $apellido;
        $this->nacionalidad = $nacionalidad;
        $this->idVisitante = $idVisitante;
    }

    public function __toString() {
        return "Visitante: " . $this->nombre . " " . $this->apellido . " (" . $this->nacionalidad . "), ID Visitante: " . $this->idVisitante;
    }
}

// Función principal
function main() {
    // Crear un museo
    $museo = new Museo("Museo del Arte Contemporáneo", 2024);
    echo $museo . PHP_EOL;

    // Crear un artista
    $artista = new Artista("1002192744", "Octavio Martinez", "Colombiana", "Hábitos Atómicos");
    echo $artista . PHP_EOL;

    // Crear una colección
    $coleccion = new Coleccion("Colección de Arte Contemporáneo");
    echo $coleccion . PHP_EOL;

    // Crear un evento
    $evento = new Evento("Exposición de Martinez", new DateTime(), "Una muestra de las obras de Martinez");
    echo $evento . PHP_EOL;

    // Crear una exposición
    $exposicion = new Exposicion("Pablo Martinez", 2024, "Arte Contemporáneo");
    echo $exposicion . PHP_EOL;

    // Crear un guía
    $guia = new Guia("Jonathan", "Tobon", "Colombiana", "1234792378");
    echo $guia . PHP_EOL;

    // Crear una obra
    $obra = new Obra("Hábitos Atómicos", "Octavio Martinez", 2020);
    echo $obra . PHP_EOL;

    // Crear un ticket
    $ticket = new Ticket("Entrada General", 50000, "TICKET1");
    echo $ticket . PHP_EOL;

    // Crear un visitante
    $visitante = new Visitante("Alexis", "Paez", "Australiana", "1003456324");
    echo $visitante . PHP_EOL;
}

// Ejecutar función principal
main();

?>

        ?>
    </body>
</html>
