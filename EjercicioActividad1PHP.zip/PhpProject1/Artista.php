

class Artista {
    private $cedula;
    private $nombreArtista;
    private $nacionalidadArtista;
    private $obrasFamosas;
    private $obra; // Array de objetos Obra
    private $coleccion; // Array de objetos Coleccion

    public function __construct($cedula, $nombreArtista, $nacionalidadArtista, $obrasFamosas) {
        $this->cedula = $cedula;
        $this->nombreArtista = $nombreArtista;
        $this->nacionalidadArtista = $nacionalidadArtista;
        $this->obrasFamosas = $obrasFamosas;
        $this->obra = [];
        $this->coleccion = [];
    }

    // Getters y Setters
    public function getCedula() {
        return $this->cedula;
    }

    public function setCedula($cedula) {
        $this->cedula = $cedula;
    }

    public function getNombreArtista() {
        return $this->nombreArtista;
    }

    public function setNombreArtista($nombreArtista) {
        $this->nombreArtista = $nombreArtista;
    }

    public function getNacionalidadArtista() {
        return $this->nacionalidadArtista;
    }

    public function setNacionalidadArtista($nacionalidadArtista) {
        $this->nacionalidadArtista = $nacionalidadArtista;
    }

    public function getObrasFamosas() {
        return $this->obrasFamosas;
    }

    public function setObrasFamosas($obrasFamosas) {
        $this->obrasFamosas = $obrasFamosas;
    }

    public function getObra() {
        return $this->obra;
    }

    public function setObra($obra) {
        $this->obra = $obra;
    }

    public function getColeccion() {
        return $this->coleccion;
    }

    public function setColeccion($coleccion) {
        $this->coleccion = $coleccion;
    }

    public function __toString() {
        return "Artista{" .
            "cedula='" . $this->cedula . '\'' .
            ", nombreArtista='" . $this->nombreArtista . '\'' .
            ", nacionalidadArtista='" . $this->nacionalidadArtista . '\'' .
            ", obrasFamosas='" . $this->obrasFamosas . '\'' .
            '}';
    }
}

// Ejemplo de uso
$artista = new Artista("12345678", "Pablo Picasso", "Español", "Guernica");
echo $artista;

?>

}
