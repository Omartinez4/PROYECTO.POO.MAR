<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of Ticket
 *
 * @author OCTAVIO MARTINEZ
 */

class Ticket {
    private $nombre;
    private $precio;
    private $codigo;
    private $evento; // Array de objetos Evento

    public function __construct($nombre, $precio, $codigo) {
        $this->nombre = $nombre;
        $this->precio = $precio;
        $this->codigo = $codigo;
        $this->evento = [];
    }

    // Getters y Setters
    public function getNombre() {
        return $this->nombre;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function getPrecio() {
        return $this->precio;
    }

    public function setPrecio($precio) {
        $this->precio = $precio;
    }

    public function getCodigo() {
        return $this->codigo;
    }

    public function setCodigo($codigo) {
        $t

