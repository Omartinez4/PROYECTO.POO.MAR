<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of Guia
 *
 * @author OCTAVIO MARTINEZ
 */

class Guia {
    private $nombre;
    private $apellido;
    private $nacionalidad;
    private $cedula;
    private $telefono;
    private $email;
    private $cantidadVisitante;
    private $visitante; // Array de objetos Visitante
    private $evento;    // Array de objetos Evento

    public function __construct($nombre, $apellido, $nacionalidad, $cedula) {
        $this->nombre = $nombre;
        $this->apellido = $apellido;
        $this->nacionalidad = $nacionalidad;
        $this->cedula = $cedula;
        $this->visitante = [];
        $this->evento = [];
    }

    // Getters y Setters
    public function getNombre() {
        return $this->nombre;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function getApellido() {
        return $this->apellido;
    }

    public function setApellido($apellido) {
        $this->apellido = $apellido;
    }

    public function getNacionalidad() {
        return $this->nacionalidad;
    }

    public function setNacionalidad($nacionalidad) {
        $this->nacionalidad = $nacionalidad;
    }

    public function getCedula() {
        return $this->cedula;
    }

    public function setCedula($cedula) {
        $this->cedula = $cedula;
    }

    public function getTelefono() {
        return $this->telefono;
    }

    public function setTelefono($telefono) {
        $this->telefono = $telefono;
    }

    public function getEmail() {
        return $this->email;
    }

    public function setEmail($email) {
        $this->email = $email;
    }

    public function getCantidadVisitante() {
        return $this->cantidadVisitante;
    }

    public function setCantidadVisitante($cantidadVisitante) {
        $this->cantidadVisitante = $cantidadVisitante;
    }

    public function getVisitante() {
        return $this->visitante;
    }

    public function setVisitante($visitante) {
        $this->visitante = $visitante;
    }

    public function getEvento() {
        return $this->evento;
    }

    public function setEvento($evento) {
        $this->evento = $evento;
    }

    public function __toString() {
        return "Guia{" .
            "nombre='" . $this->nombre . '\'' .
            ", apellido='" . $this->apellido . '\'' .
            ", nacionalidad='" . $this->nacionalidad . '\'' .
            '}';
    }
}

// Ejemplo de uso
$guia = new Guia("Juan", "Pérez", "Ecuatoriano", "123456789");
echo $guia;

?>

