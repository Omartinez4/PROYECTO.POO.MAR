<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of Obra
 *
 * @author OCTAVIO MARTINEZ
 */


class Obra {
    private $nombre;
    private $nombreArtista;
    private $añoExposicion;
    private $fecha; // Almacena la fecha como un objeto DateTime
    private $coleccion; // Array de objetos Coleccion
    private $artista;   // Array de objetos Artista

    public function __construct($nombre, $nombreArtista, $añoExposicion) {
        $this->nombre = $nombre;
        $this->nombreArtista = $nombreArtista;
        $this->añoExposicion = $añoExposicion;
        $this->coleccion = [];
        $this->artista = [];
    }

    // Getters y Setters
    public function getNombre() {
        return $this->nombre;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function getNombreArtista() {
        return $this->nombreArtista;
    }

    public function setNombreArtista($nombreArtista) {
        $this->nombreArtista = $nombreArtista;
    }

    public function getAñoExposicion() {
        return $this->añoExposicion;
    }

    public function setAñoExposicion($añoExposicion) {
        $this->añoExposicion = $añoExposicion;
    }

    public function getFecha() {
        return $this->fecha;
    }

    public function setFecha($fecha) {
        $this->fecha = new DateTime($fecha);
    }

    public function getColeccion() {
        return $this->coleccion;
    }

    public function setColeccion($coleccion) {
        $this->coleccion = $coleccion;
    }

    public function getArtista() {
        return $this->artista;
    }

    public function setArtista($artista) {
        $this->artista = $artista;
    }

    public function __toString() {
        return "Obra{" .
            "nombre='" . $this->nombre . '\'' .
            ", nombreArtista='" . $this->nombreArtista . '\'' .
            ", añoExposicion=" . $this->añoExposicion .
            '}';
    }
}

// Ejemplo de uso
$obra = new Obra("La noche estrellada", "Vincent van Gogh", 1889);
$obra->setFecha("1889-06-01");
echo $obra;

?>

