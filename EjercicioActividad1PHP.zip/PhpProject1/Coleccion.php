<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of Coleccion
 *
 * @author OCTAVIO MARTINEZ
 */
class Coleccion {
  
    private $nombre;
    private $obra; // Obra en formato de cadena
    private $obraList; // Array de objetos Obra
    private $artistaList; // Array de objetos Artista

    public function __construct($nombre) {
        $this->nombre = $nombre;
        $this->obraList = [];
        $this->artistaList = [];
    }

    // Getters y Setters
    public function getNombre() {
        return $this->nombre;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function getObra() {
        return $this->obra;
    }

    public function setObra($obra) {
        $this->obra = $obra;
    }

    public function getObraList() {
        return $this->obraList;
    }

    public function setObraList($obraList) {
        $this->obraList = $obraList;
    }

    public function getArtistaList() {
        return $this->artistaList;
    }

    public function setArtistaList($artistaList) {
        $this->artistaList = $artistaList;
    }

    public function __toString() {
        return "Coleccion{" .
            "nombre='" . $this->nombre . '\'' .
            '}';
    }
}

// Ejemplo de uso
$coleccion = new Coleccion("Colección de Arte Moderno");
echo $coleccion;

?>

}
