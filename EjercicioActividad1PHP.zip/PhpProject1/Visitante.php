<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of Visitante
 *
 * @author OCTAVIO MARTINEZ
 */

class Visitante {
    private $nombre;
    private $apellido;
    private $nacionalidad;
    private $cedula;
    private $telefono;
    private $email;
    private $fechaIngreso; // Almacena la fecha como un objeto DateTime

    public function __construct($nombre, $apellido, $nacionalidad, $cedula) {
        $this->nombre = $nombre;
        $this->apellido = $apellido;
        $this->nacionalidad = $nacionalidad;
        $this->cedula = $cedula;
    }

    // Getters y Setters
    public function getNombre() {
        return $this->nombre;
   
