<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of Evento
 *
 * @author OCTAVIO MARTINEZ
 */

class Evento {
    private $nombre;
    private $fecha; // Almacena la fecha como un objeto DateTime
    private $descripcion;
    private $participantes;
    private $obra; // Array de objetos Obra

    public function __construct($nombre, $fecha, $descripcion) {
        $this->nombre = $nombre;
        $this->fecha = new DateTime($fecha); // Inicializa como objeto DateTime
        $this->descripcion = $descripcion;
        $this->obra = [];
    }

    // Getters y Setters
    public function getNombre() {
        return $this->nombre;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function getFecha() {
        return $this->fecha;
    }

    public function setFecha($fecha) {
        $this->fecha = new DateTime($fecha);
    }

    public function getDescripcion() {
        return $this->descripcion;
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }

    public function getParticipantes() {
        return $this->participantes;
    }

    public function setParticipantes($participantes) {
        $this->participantes = $participantes;
    }

    public function getObra() {
        return $this->obra;
    }

    public function setObra($obra) {
        $this->obra = $obra;
    }

    public function __toString() {
        return "Evento{" .
            "nombre='" . $this->nombre . '\'' .
            ", fecha=" . $this->fecha->format('Y-m-d H:i:s') . // Formato de fecha
            ", descripcion='" . $this->descripcion . '\'' .
            '}';
    }
}

// Ejemplo de uso
$evento = new Evento("Exposición de Arte", "2024-10-11", "Una exposición de arte moderno.");
echo $evento;

?>

