<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of Museo
 *
 * @author OCTAVIO MARTINEZ
 */


class Museo {
    private $ubicacionMuseo;
    private $añoFundacion;
    private $visitante; // Array de objetos Visitante
    private $guia;      // Array de objetos Guia

    public function __construct($ubicacionMuseo, $añoFundacion) {
        $this->ubicacionMuseo = $ubicacionMuseo;
        $this->añoFundacion = $añoFundacion;
        $this->visitante = [];
        $this->guia = [];
    }

    // Getters y Setters
    public function getUbicacionMuseo() {
        return $this->ubicacionMuseo;
    }

    public function setUbicacionMuseo($ubicacionMuseo) {
        $this->ubicacionMuseo = $ubicacionMuseo;
    }

    public function getAñoFundacion() {
        return $this->añoFundacion;
    }

    public function setAñoFundacion($añoFundacion) {
