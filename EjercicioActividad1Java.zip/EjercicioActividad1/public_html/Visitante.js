/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
class Visitante {
    constructor(nombre, apellido, nacionalidad, cedula) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.nacionalidad = nacionalidad;
        this.cedula = cedula;
        this.telefono = null; // Inicializa como null
        this.email = null;    // Inicializa como null
        this.fechaIngreso = null; // Inicializa como null
    }

    // Getters y Setters
    getNombre() {
        return this.nombre;
    }

    setNombre(nombre) {
        this.nombre = nombre;
    }

    getApellido() {
        return this.apellido;
    }

    setApellido(apellido) {
        this.apellido = apellido;
    }

    getNacionalidad() {
        return this.nacionalidad;
    }

    setNacionalidad(nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    getCedula() {
        return this.cedula;
    }

    setCedula(cedula) {
        this.cedula = cedula;
    }

    getTelefono() {
        return this.telefono;
    }

    setTelefono(telefono) {
        this.telefono = telefono;
    }

    getEmail() {
        return this.email;
    }

    setEmail(email) {
        this.email = email;
    }

    getFechaIngreso() {
        return this.fechaIngreso;
    }

    setFechaIngreso(fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    toString() {
        return `Visitante{nombre='${this.nombre}', apellido='${this.apellido}'}`;
    }
}


