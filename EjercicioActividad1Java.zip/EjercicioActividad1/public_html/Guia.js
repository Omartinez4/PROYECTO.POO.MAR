/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
class Guia {
    constructor(nombre, apellido, nacionalidad, cedula) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.nacionalidad = nacionalidad;
        this.cedula = cedula;
        this.telefono = '';
        this.email = '';
        this.cantidadVisitante = 0;
        this.visitante = [];
        this.evento = [];
    }

    // Getters y Setters
    getNombre() {
        return this.nombre;
    }

    setNombre(nombre) {
        this.nombre = nombre;
    }

    getApellido() {
        return this.apellido;
    }

    setApellido(apellido) {
        this.apellido = apellido;
    }

    getNacionalidad() {
        return this.nacionalidad;
    }

    setNacionalidad(nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    getCedula() {
        return this.cedula;
    }

    setCedula(cedula) {
        this.cedula = cedula;
    }

    getTelefono() {
        return this.telefono;
    }

    setTelefono(telefono) {
        this.telefono = telefono;
    }

    getEmail() {
        return this.email;
    }

    setEmail(email) {
        this.email = email;
    }

    getCantidadVisitante() {
        return this.cantidadVisitante;
    }

    setCantidadVisitante(cantidadVisitante) {
        this.cantidadVisitante = cantidadVisitante;
    }

    getVisitante() {
        return this.visitante;
    }

    setVisitante(visitante) {
        this.visitante = visitante;
    }

    getEvento() {
        return this.evento;
    }

    setEvento(evento) {
        this.evento = evento;
    }

    toString() {
        return `Guia{nombre='${this.nombre}', apellido='${this.apellido}', nacionalidad='${this.nacionalidad}'}`;
    }
}


