/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
class Exposicion {
    constructor(nombreExposicion, añoExposicion, tipoExposicion) {
        this.nombreExposicion = nombreExposicion;
        this.añoExposicion = añoExposicion;
        this.tipoExposicion = tipoExposicion;
    }

    // Getters y Setters
    getNombreExposicion() {
        return this.nombreExposicion;
    }

    setNombreExposicion(nombreExposicion) {
        this.nombreExposicion = nombreExposicion;
    }

    getAñoExposicion() {
        return this.añoExposicion;
    }

    setAñoExposicion(añoExposicion) {
        this.añoExposicion = añoExposicion;
    }

    getTipoExposicion() {
        return this.tipoExposicion;
    }

    setTipoExposicion(tipoExposicion) {
        this.tipoExposicion = tipoExposicion;
    }

    toString() {
        return `Exposicion{nombreExposicion='${this.nombreExposicion}', añoExposicion=${this.añoExposicion}}`;
    }
}
