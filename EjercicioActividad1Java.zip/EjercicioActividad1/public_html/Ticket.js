/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
class Ticket {
    constructor(nombre, precio, codigo) {
        this.nombre = nombre;
        this.precio = precio;
        this.codigo = codigo;
        this.evento = []; // Inicializa como un array vacío
    }

    // Getters y Setters
    getNombre() {
        return this.nombre;
    }

    setNombre(nombre) {
        this.nombre = nombre;
    }

    getPrecio() {
        return this.precio;
    }

    setPrecio(precio) {
        this.precio = precio;
    }

    getCodigo() {
        return this.codigo;
    }

    setCodigo(codigo) {
        this.codigo = codigo;
    }

    getEvento() {
        return this.evento;
    }

    setEvento(evento) {
        this.evento = evento;
    }

    toString() {
        return `Ticket{nombre='${this.nombre}', precio=${this.precio}, codigo='${this.codigo}'}`;
    }
}


