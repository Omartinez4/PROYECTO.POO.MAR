/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */

class Coleccion {
    constructor(nombre) {
        this.nombre = nombre;
        this.obraList = []; // Lista de Obra
        this.artistaList = []; // Lista de Artista
    }

    // Getters y Setters
    getNombre() {
        return this.nombre;
    }

    setNombre(nombre) {
        this.nombre = nombre;
    }

    getObra() {
        return this.obra;
    }

    setObra(obra) {
        this.obra = obra;
    }

    getObraList() {
        return this.obraList;
    }

    setObraList(obraList) {
        this.obraList = obraList;
    }

    getArtistaList() {
        return this.artistaList;
    }

    setArtistaList(artistaList) {
        this.artistaList = artistaList;
    }

    toString() {
        return `Coleccion{nombre='${this.nombre}'}`;
    }
}

