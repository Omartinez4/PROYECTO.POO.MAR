/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
class Evento {
    constructor(nombre, fecha, descripcion) {
        this.nombre = nombre;
        this.fecha = fecha; // Se espera que `fecha` sea un objeto Date
        this.descripcion = descripcion;
        this.participantes = ""; // Inicializamos como cadena vacía
        this.obraList = []; // Lista de Obra
    }

    // Getters y Setters
    getNombre() {
        return this.nombre;
    }

    setNombre(nombre) {
        this.nombre = nombre;
    }

    getFecha() {
        return this.fecha;
    }

    setFecha(fecha) {
        this.fecha = fecha;
    }

    getDescripcion() {
        return this.descripcion;
    }

    setDescripcion(descripcion) {
        this.descripcion = descripcion;
    }

    getParticipantes() {
        return this.participantes;
    }

    setParticipantes(participantes) {
        this.participantes = participantes;
    }

    getObraList() {
        return this.obraList;
    }

    setObraList(obraList) {
        this.obraList = obraList;
    }

    toString() {
        return `Evento{nombre='${this.nombre}', fecha='${this.fecha.toISOString()}', descripcion='${this.descripcion}'}`;
    }
}


