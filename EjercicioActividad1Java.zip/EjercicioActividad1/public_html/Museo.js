/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
class Museo {
    constructor(ubicacionMuseo, añoFundacion) {
        this.ubicacionMuseo = ubicacionMuseo;
        this.añoFundacion = añoFundacion;
        this.visitante = [];
        this.guia = [];
    }

    // Getters y Setters
    getUbicacionMuseo() {
        return this.ubicacionMuseo;
    }

    setUbicacionMuseo(ubicacionMuseo) {
        this.ubicacionMuseo = ubicacionMuseo;
    }

    getAñoFundacion() {
        return this.añoFundacion;
    }

    setAñoFundacion(añoFundacion) {
        this.añoFundacion = añoFundacion;
    }

    getVisitante() {
        return this.visitante;
    }

    setVisitante(visitante) {
        this.visitante = visitante;
    }

    getGuia() {
        return this.guia;
    }

    setGuia(guia) {
        this.guia = guia;
    }

    toString() {
        return `Museo{ubicacionMuseo='${this.ubicacionMuseo}', añoFundacion=${this.añoFundacion}}`;
    }
}
