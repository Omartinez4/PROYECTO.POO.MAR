/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
class Artista {
    constructor(cedula, nombreArtista, nacionalidadArtista, obrasFamosas) {
        this.cedula = cedula;
        this.nombreArtista = nombreArtista;
        this.nacionalidadArtista = nacionalidadArtista;
        this.obrasFamosas = obrasFamosas;
        this.obra = []; // Lista de Obra
        this.coleccion = []; // Lista de Coleccion
    }

    // Getters y Setters
    getCedula() {
        return this.cedula;
    }

    setCedula(cedula) {
        this.cedula = cedula;
    }

    getNombreArtista() {
        return this.nombreArtista;
    }

    setNombreArtista(nombreArtista) {
        this.nombreArtista = nombreArtista;
    }

    getNacionalidadArtista() {
        return this.nacionalidadArtista;
    }

    setNacionalidadArtista(nacionalidadArtista) {
        this.nacionalidadArtista = nacionalidadArtista;
    }

    getObrasFamosas() {
        return this.obrasFamosas;
    }

    setObrasFamosas(obrasFamosas) {
        this.obrasFamosas = obrasFamosas;
    }

    getObra() {
        return this.obra;
    }

    setObra(obra) {
        this.obra = obra;
    }

    getColeccion() {
        return this.coleccion;
    }

    setColeccion(coleccion) {
        this.coleccion = coleccion;
    }

    toString() {
        return `Artista{cedula='${this.cedula}', nombreArtista='${this.nombreArtista}', ` +
               `nacionalidadArtista='${this.nacionalidadArtista}', obrasFamosas='${this.obrasFamosas}'}`;
    }
}


