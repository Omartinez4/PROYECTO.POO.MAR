/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
class Obra {
    constructor(nombre, nombreArtista, añoExposicion) {
        this.nombre = nombre;
        this.nombreArtista = nombreArtista;
        this.añoExposicion = añoExposicion;
        this.coleccion = [];
        this.artista = [];
        this.fecha = null; // Puedes inicializarlo más tarde
    }

    // Getters y Setters
    getNombre() {
        return this.nombre;
    }

    setNombre(nombre) {
        this.nombre = nombre;
    }

    getNombreArtista() {
        return this.nombreArtista;
    }

    setNombreArtista(nombreArtista) {
        this.nombreArtista = nombreArtista;
    }

    getAñoExposicion() {
        return this.añoExposicion;
    }

    setAñoExposicion(añoExposicion) {
        this.añoExposicion = añoExposicion;
    }

    getFecha() {
        return this.fecha;
    }

    setFecha(fecha) {
        this.fecha = fecha;
    }

    getColeccion() {
        return this.coleccion;
    }

    setColeccion(coleccion) {
        this.coleccion = coleccion;
    }

    getArtista() {
        return this.artista;
    }

    setArtista(artista) {
        this.artista = artista;
    }

    toString() {
        return `Obra{nombre='${this.nombre}', nombreArtista='${this.nombreArtista}', añoExposicion=${this.añoExposicion}}`;
    }
}


